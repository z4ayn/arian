ARIAN PERSONAL WEBSITE — UPDATE

Avatar:
- assets/arian-avatar.jpg is now your original uploaded photo.
- The website crops it into a circular avatar automatically.

Website:
- Upload/replace index.html and the assets/arian-avatar.jpg file in your GitHub repo.
- Repository: https://github.com/z4ayn/arian
- Website: https://z4ayn.github.io/arian/

Instagram Reels auto-feed:
- It is NOT activated by this static ZIP alone. GitHub Pages only serves static files.
- To auto-show each new public Reel, we must connect the Creator account to Meta's Instagram API and use a secure serverless endpoint (for example, a Cloudflare Worker) to fetch recent media.
- Never put your Instagram password or API access token inside index.html or a public GitHub repository.
- Your account must be a Creator/Business professional account and you must authorize API access. Do not send your password here.
- Once the API connection is ready, the website can request the latest media from the secure endpoint and render it automatically.

Music:
- If you want your own background track, add an audio file named assets/ambient.mp3.
